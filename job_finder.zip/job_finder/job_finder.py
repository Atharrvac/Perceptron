from flask import Flask, request, jsonify
from flask_cors import CORS
import random
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)

# Enhanced mock data generator with more realistic job details
def generate_mock_jobs(query, location, skills):
    tech_companies = ["Google", "Microsoft", "Amazon", "Apple", "Tesla", "Netflix", 
                     "Meta", "Twitter", "Uber", "Airbnb", "Stripe", "Salesforce"]
    finance_companies = ["Goldman Sachs", "JPMorgan Chase", "Morgan Stanley", "Bank of America"]
    healthcare_companies = ["Pfizer", "Johnson & Johnson", "Merck", "UnitedHealth Group"]
    
    all_companies = tech_companies + finance_companies + healthcare_companies
    job_types = ["Senior", "Junior", "Mid-level", "Lead", "Principal", "Staff"]
    
    jobs = []
    num_jobs = random.randint(8, 15)
    
    for i in range(num_jobs):
        skill_match = random.uniform(0.5, 0.95) if skills else 0.7
        days_ago = random.randint(0, 30)
        is_remote = random.choice([True, False])
        company = random.choice(all_companies)
        
        # Company-specific details
        if company in tech_companies:
            salary_range = f"${random.randint(90, 250)}K"
            perks = ["Stock options", "Flexible hours", "Tech budget"]
        elif company in finance_companies:
            salary_range = f"${random.randint(100, 300)}K"
            perks = ["Bonus", "Retirement plan", "Health insurance"]
        else:
            salary_range = f"${random.randint(80, 200)}K"
            perks = ["Health benefits", "Paid leave", "Wellness program"]
        
        jobs.append({
            "title": f"{random.choice(job_types)} {query}",
            "company": company,
            "location": location if not is_remote else "Remote",
            "description": f"We're looking for a {query} with experience in {', '.join(skills) if skills else 'relevant technologies'}. " +
                          f"Join our {random.choice(['innovative', 'fast-growing', 'award-winning'])} team and work on " +
                          f"{random.choice(['cutting-edge', 'exciting', 'challenging'])} projects!",
            "posted_date": (datetime.now() - timedelta(days=days_ago)).strftime("%b %d"),
            "score": skill_match,
            "salary": salary_range,
            "is_remote": is_remote,
            "perks": random.sample(perks, 2),
            "logo_color": f"hsl({random.randint(0, 360)}, 70%, 60%)"  # Random vibrant color for logo
        })
    
    return sorted(jobs, key=lambda x: x['score'], reverse=True)

@app.route('/api/jobs', methods=['POST'])
def get_jobs():
    try:
        data = request.get_json()
        query = data.get('query', 'Software Engineer')
        location = data.get('location', 'New York')
        skills = data.get('skills', [])
        
        jobs = generate_mock_jobs(query, location, skills)
        
        return jsonify({
            "status": "success",
            "count": len(jobs),
            "jobs": jobs[:12]  # Return top 12 jobs
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/')
def home():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HDTN Jobs Finder</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <style>
            :root {
                --primary: #6a11cb;
                --secondary: #2575fc;
                --dark: #1a1a2e;
                --light: #f8f9fa;
                --success: #38ef7d;
                --danger: #f85032;
                --warning: #ffb347;
                --gray: #6c757d;
                --white: #ffffff;
                --card-bg: rgba(255, 255, 255, 0.95);
            }
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', sans-serif;
                background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
                color: var(--dark);
                line-height: 1.6;
                min-height: 100vh;
                overflow-x: hidden;
            }
            
            .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 2rem;
                opacity: 0;
                transform: translateX(-50px);
                animation: slideIn 0.8s forwards 0.2s;
            }
            
            @keyframes slideIn {
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            header {
                text-align: center;
                margin-bottom: 3rem;
                background: linear-gradient(135deg, var(--primary), var(--secondary));
                -webkit-background-clip: text;
                background-clip: text;
                color: transparent;
                padding: 1rem;
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(106, 17, 203, 0.1);
                transform: translateY(-20px);
                opacity: 0;
                animation: fadeInDown 0.8s forwards 0.4s;
            }
            
            @keyframes fadeInDown {
                to {
                    transform: translateY(0);
                    opacity: 1;
                }
            }
            
            h1 {
                font-size: 2.8rem;
                font-weight: 700;
                margin-bottom: 1rem;
            }
            
            .tagline {
                color: var(--gray);
                font-size: 1.2rem;
                margin-bottom: 0;
                font-weight: 300;
            }
            
            .search-box {
                background: var(--white);
                border-radius: 16px;
                padding: 2.5rem;
                box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
                margin-bottom: 3rem;
                border: 1px solid rgba(255, 255, 255, 0.3);
                backdrop-filter: blur(10px);
                transform: scale(0.95);
                opacity: 0;
                animation: scaleIn 0.6s forwards 0.6s;
            }
            
            @keyframes scaleIn {
                to {
                    transform: scale(1);
                    opacity: 1;
                }
            }
            
            .search-form {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1.5rem;
                margin-bottom: 1rem;
            }
            
            .form-group {
                margin-bottom: 0;
                opacity: 0;
                transform: translateY(20px);
            }
            
            .form-group:nth-child(1) { animation: fadeInUp 0.5s forwards 0.8s; }
            .form-group:nth-child(2) { animation: fadeInUp 0.5s forwards 0.9s; }
            .form-group:nth-child(3) { animation: fadeInUp 0.5s forwards 1.0s; }
            .search-btn { animation: fadeInUp 0.5s forwards 1.1s; }
            
            @keyframes fadeInUp {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            label {
                display: block;
                margin-bottom: 0.75rem;
                font-weight: 500;
                color: var(--dark);
                font-size: 0.95rem;
            }
            
            input {
                width: 100%;
                padding: 0.9rem 1.2rem;
                border: 1px solid rgba(0, 0, 0, 0.1);
                border-radius: 10px;
                font-size: 1rem;
                transition: all 0.3s ease;
                background: rgba(255, 255, 255, 0.8);
            }
            
            input:focus {
                outline: none;
                border-color: var(--primary);
                box-shadow: 0 0 0 3px rgba(106, 17, 203, 0.2);
                background: var(--white);
            }
            
            button {
                background: linear-gradient(135deg, var(--primary), var(--secondary));
                color: white;
                border: none;
                padding: 0.9rem 1.8rem;
                border-radius: 10px;
                font-size: 1rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 0.5rem;
                box-shadow: 0 4px 15px rgba(106, 17, 203, 0.3);
            }
            
            button:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(106, 17, 203, 0.4);
            }
            
            button:active {
                transform: translateY(0);
            }
            
            button:disabled {
                background: var(--gray);
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }
            
            .search-btn {
                align-self: flex-end;
                height: 100%;
            }
            
            .results-count {
                font-size: 1.1rem;
                margin-bottom: 1.5rem;
                color: var(--gray);
                opacity: 0;
                transform: translateY(20px);
                animation: fadeInUp 0.5s forwards 0.3s;
            }
            
            .results-count strong {
                color: var(--primary);
                font-weight: 700;
            }
            
            .jobs-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
                gap: 2rem;
            }
            
            .job-card {
                background: var(--card-bg);
                border-radius: 16px;
                overflow: hidden;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.1);
                border: 1px solid rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(5px);
                opacity: 0;
                transform: translateY(30px);
            }
            
            .job-card:nth-child(1) { animation: cardAppear 0.6s forwards 0.4s; }
            .job-card:nth-child(2) { animation: cardAppear 0.6s forwards 0.5s; }
            .job-card:nth-child(3) { animation: cardAppear 0.6s forwards 0.6s; }
            .job-card:nth-child(4) { animation: cardAppear 0.6s forwards 0.7s; }
            .job-card:nth-child(5) { animation: cardAppear 0.6s forwards 0.8s; }
            .job-card:nth-child(6) { animation: cardAppear 0.6s forwards 0.9s; }
            
            @keyframes cardAppear {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .job-card:hover {
                transform: translateY(-10px) scale(1.02);
                box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
            }
            
            .job-header {
                padding: 1.8rem;
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
                position: relative;
            }
            
            .company-logo {
                position: absolute;
                right: 1.5rem;
                top: 1.5rem;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: bold;
                font-size: 1rem;
            }
            
            .job-title {
                font-size: 1.3rem;
                font-weight: 700;
                margin-bottom: 0.5rem;
                color: var(--dark);
                line-height: 1.4;
            }
            
            .job-company {
                font-size: 1.05rem;
                color: var(--primary);
                font-weight: 600;
                margin-bottom: 0.75rem;
                display: inline-block;
            }
            
            .job-meta {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 1rem;
                margin-bottom: 0.5rem;
                font-size: 0.9rem;
                color: var(--gray);
            }
            
            .job-meta i {
                margin-right: 0.3rem;
                opacity: 0.7;
            }
            
            .job-body {
                padding: 1.8rem;
            }
            
            .job-description {
                margin-bottom: 1.5rem;
                color: var(--gray);
                display: -webkit-box;
                -webkit-line-clamp: 3;
                -webkit-box-orient: vertical;
                overflow: hidden;
                line-height: 1.6;
            }
            
            .job-perks {
                display: flex;
                gap: 0.5rem;
                margin-bottom: 1.5rem;
                flex-wrap: wrap;
            }
            
            .perk {
                background: rgba(106, 17, 203, 0.1);
                color: var(--primary);
                padding: 0.35rem 0.7rem;
                border-radius: 50px;
                font-size: 0.75rem;
                font-weight: 600;
            }
            
            .job-footer {
                padding: 1.2rem 1.8rem;
                background: rgba(245, 247, 250, 0.7);
                border-top: 1px solid rgba(0, 0, 0, 0.05);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .job-score {
                font-weight: 700;
                color: var(--success);
                font-size: 0.95rem;
            }
            
            .apply-btn {
                padding: 0.6rem 1.2rem;
                font-size: 0.9rem;
                border-radius: 8px;
                background: linear-gradient(135deg, var(--primary), var(--secondary));
            }
            
            .apply-btn:hover {
                transform: translateY(-2px);
            }
            
            .apply-btn:active {
                transform: translateY(0);
            }
            
            .remote-badge {
                background: linear-gradient(135deg, #38ef7d, #11998e);
                color: white;
                padding: 0.3rem 0.7rem;
                border-radius: 50px;
                font-size: 0.75rem;
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                gap: 0.25rem;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
            
            .loading {
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 4rem;
            }
            
            .spinner {
                width: 50px;
                height: 50px;
                border: 4px solid rgba(106, 17, 203, 0.1);
                border-radius: 50%;
                border-top-color: var(--primary);
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
            
            .error-message {
                color: var(--danger);
                text-align: center;
                padding: 3rem;
                font-weight: 500;
                background: rgba(248, 80, 50, 0.05);
                border-radius: 12px;
                margin: 1rem 0;
            }
            
            .initial-state {
                text-align: center;
                padding: 4rem 0;
                color: var(--gray);
                opacity: 0;
                transform: translateY(20px);
                animation: fadeInUp 0.6s forwards 0.8s;
            }
            
            .initial-state i {
                font-size: 3.5rem;
                margin-bottom: 1.5rem;
                opacity: 0.3;
            }
            
            .initial-state h3 {
                font-weight: 600;
                margin-bottom: 0.5rem;
                color: var(--dark);
            }
            
            footer {
                text-align: center;
                margin-top: 4rem;
                padding: 2rem 0;
                color: var(--gray);
                font-size: 0.9rem;
                opacity: 0;
                animation: fadeIn 0.6s forwards 1.2s;
            }
            
            @keyframes fadeIn {
                to { opacity: 1; }
            }
            
            @media (max-width: 768px) {
                .container {
                    padding: 1.5rem;
                }
                
                h1 {
                    font-size: 2.2rem;
                }
                
                .search-box {
                    padding: 1.5rem;
                }
                
                .search-form {
                    grid-template-columns: 1fr;
                }
                
                .jobs-grid {
                    grid-template-columns: 1fr;
                }
                
                .job-card {
                    margin-bottom: 1.5rem;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <header>
                <h1>HDTN Jobs Finder</h1>
                <p class="tagline">Find your dream job with our intelligent matching system</p>
            </header>
            
            <div class="search-box">
                <div class="search-form">
                    <div class="form-group">
                        <label for="query">Job Title</label>
                        <input type="text" id="query" placeholder="e.g. Software Engineer" value="Software Engineer">
                    </div>
                    <div class="form-group">
                        <label for="location">Location</label>
                        <input type="text" id="location" placeholder="e.g. New York" value="New York">
                    </div>
                    <div class="form-group">
                        <label for="skills">Skills</label>
                        <input type="text" id="skills" placeholder="e.g. Python, JavaScript, React">
                    </div>
                    <button class="search-btn" onclick="searchJobs()">
                        <i class="fas fa-search"></i> Search Jobs
                    </button>
                </div>
            </div>
            
            <div id="results">
                <div class="initial-state">
                    <i class="fas fa-briefcase"></i>
                    <h3>Start your job search</h3>
                    <p>Enter your criteria and click "Search Jobs" to find matching positions</p>
                </div>
            </div>
            
            <footer>
                <p>© 2023 HDTN Jobs Finder. All rights reserved.</p>
            </footer>
        </div>

        <script>
            async function searchJobs() {
                const query = document.getElementById('query').value;
                const location = document.getElementById('location').value;
                const skills = document.getElementById('skills').value;
                
                // Show loading state
                document.getElementById('results').innerHTML = `
                    <div class="loading">
                        <div class="spinner"></div>
                    </div>
                `;
                
                try {
                    const res = await fetch('/api/jobs', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ 
                            query, 
                            location, 
                            skills: skills.split(',').map(s => s.trim()) 
                        })
                    });
                    
                    const data = await res.json();
                    
                    if (data.status === 'error') {
                        document.getElementById('results').innerHTML = `
                            <div class="error-message">
                                <i class="fas fa-exclamation-circle"></i>
                                <p>${data.message}</p>
                            </div>
                        `;
                        return;
                    }
                    
                    let html = `
                        <div class="results-count">
                            Found <strong>${data.count}</strong> matching jobs
                        </div>
                        <div class="jobs-grid">
                    `;
                    
                    if (data.jobs.length === 0) {
                        html = `
                            <div class="initial-state">
                                <i class="fas fa-frown"></i>
                                <h3>No jobs found</h3>
                                <p>Try adjusting your search criteria</p>
                            </div>
                        `;
                    } else {
                        data.jobs.forEach((job, i) => {
                            html += `
                                <div class="job-card">
                                    <div class="job-header">
                                        <div class="company-logo" style="background: ${job.logo_color}">
                                            ${job.company.charAt(0)}
                                        </div>
                                        <h3 class="job-title">${job.title}</h3>
                                        <p class="job-company">${job.company}</p>
                                        <div class="job-meta">
                                            <span><i class="fas fa-map-marker-alt"></i> ${job.location}</span>
                                            <span><i class="fas fa-money-bill-wave"></i> ${job.salary}</span>
                                            ${job.is_remote ? '<span class="remote-badge"><i class="fas fa-home"></i> Remote</span>' : ''}
                                        </div>
                                    </div>
                                    <div class="job-body">
                                        <p class="job-description">${job.description}</p>
                                        <div class="job-perks">
                                            ${job.perks.map(perk => `<span class="perk">${perk}</span>`).join('')}
                                        </div>
                                    </div>
                                    <div class="job-footer">
                                        <div>
                                            <span>Posted: ${job.posted_date}</span>
                                            <span> • </span>
                                            <span class="job-score">Match: ${(job.score * 100).toFixed(0)}%</span>
                                        </div>
                                        <button class="apply-btn" id="apply-${i}" onclick="markAsApplied(${i})">
                                            <i class="fas fa-paper-plane"></i> Apply
                                        </button>
                                    </div>
                                </div>
                            `;
                        });
                        html += `</div>`;
                    }
                    
                    document.getElementById('results').innerHTML = html;
                    
                    // Animate the cards in
                    const cards = document.querySelectorAll('.job-card');
                    cards.forEach((card, index) => {
                        card.style.animation = `cardAppear 0.6s forwards ${index * 0.1 + 0.3}s`;
                    });
                } catch (error) {
                    document.getElementById('results').innerHTML = `
                        <div class="error-message">
                            <i class="fas fa-exclamation-circle"></i>
                            <p>Failed to fetch jobs. Please try again.</p>
                        </div>
                    `;
                }
            }
            
            function markAsApplied(index) {
                const btn = document.getElementById(`apply-${index}`);
                btn.innerHTML = '<i class="fas fa-check"></i> Applied';
                btn.disabled = true;
                btn.style.background = 'linear-gradient(135deg, var(--success), #11998e)';
                btn.style.transform = 'translateY(0)';
            }
        </script>
    </body>
    </html>
    """

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)